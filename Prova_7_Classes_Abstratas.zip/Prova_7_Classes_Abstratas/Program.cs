﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFramework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int personagem = 0;

            while (personagem >= 0)
            {
                Console.Clear();

                Console.WriteLine("----Selecione o seu personagem----\n\n" +
                "1 - Guerreiro\n" +
                "2 - Mago\n" +
                "3 - Ranger\n" +
                "0 - Sair\n\n" +
                "Digite a sua opcao: "
                );

                personagem = int.Parse(Console.ReadLine() ?? "");

                Console.Clear();

                switch (personagem)
                {
                    case 1:

                        Guerreiro guerreiro = new Guerreiro();
                        break;

                    case 2:

                        Mago mago = new Mago();
                        break;

                    case 3:

                        Ranger ranger = new Ranger();
                        break;

                    case 0:

                        personagem = -1;
                        break;

                    default:

                        Console.WriteLine("Opcao invalida ! - Prima Enter para voltar");
                        Console.ReadKey();
                        break;
                }

                //Console.Read();
            }
        }
    }
}

