﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Mago : Patterns
{
    protected Random dado = new Random();
    protected int movimento, dano, defesa, escolha, soma = 0;
    
    public Mago()
    {
        do
        {

            Console.WriteLine("Bem vindo Mago\n" +
                "Qual a sua proxima ação ?\n" +
                "1 - Atacar\n" +
                "2 - Andar\n" +
                "3 - Defender\n" +
                "0 - Voltar para a escolha de personagem\n");

            escolha = int.Parse(Console.ReadLine());

            switch (escolha)
            {
                case 1:

                    Ataque();
                    Console.Clear();

                    break;

                case 2:

                    Andar();
                    Console.Clear();

                    break;


                case 3:

                    Defender();
                    Console.Clear();

                    break;


                case 0:

                    goto sair;

                default:
                    break;
            }

        } while (true);

        sair: { }
    }

    public void Andar()
    {

        string modo = "correu";
        movimento = dado.Next(1, 4);

        Console.WriteLine($"O mago {modo} {movimento} casas nesse turno\n" + $"Precione enter para continuar...");
        Console.ReadLine();

    }

    public void Ataque()
    {
        int ataque = 0;
        int i = 0;
        string arma = " ";

        Console.WriteLine("Escolha o tipo de ataque: \n\n");

        Console.WriteLine(
                "1 - Fogo\n" +
                "2 - Terra\n" +
                "3 - Ar\n" +
                "4 - Agua\n\n");
        
        ataque = int.Parse(Console.ReadLine() ?? "");

        switch (ataque)
        {
            case 1:

                Console.WriteLine("Ataque com fogo\n");
                arma = "fogo";
                break;

            case 2:

                Console.WriteLine("Ataque com Terra\n");
                arma = "terra";
                break;

            case 3:

                Console.WriteLine("Ataque com ar\n");
                arma = "ar";
                break;

            case 4:

                Console.WriteLine("Ataque com agua\n");
                arma = "agua";
                break;

            default:

                break;
        }

        dano = dado.Next(1, 7);
        soma += dano;
        
        Console.WriteLine($"O dano acertado pelo ataque com {arma} do mago foi de {soma}\n" + $"Precione enter para continuar...");
        Console.ReadLine();
        soma = 0;
    }

    public void Defender()
    {
        string aparato = "barreira de ar";
        defesa = dado.Next(1, 7);

        Console.WriteLine($"O guerreiro defendeu com {aparato} {defesa} de dano\n" + $"Precione enter para continuar...");
        Console.ReadLine();

    }
}