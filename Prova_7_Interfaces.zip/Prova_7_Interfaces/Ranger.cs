﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

internal class Ranger : Patterns
{
    protected Random dado = new Random();
    protected int movimento, dano, defesa, escolha, soma = 0;
    
    public Ranger()
    {
        do
        {
            Console.WriteLine("Bem vindo Ranger\n" +
                "Qual a sua proxima ação ?\n" +
                "1 - Atacar\n" +
                "2 - Andar\n" +
                "3 - Defender\n" +
                "0 - Voltar para a escolha de personagem\n");

            escolha = int.Parse(Console.ReadLine());

            switch (escolha)
            {
                case 1:

                    Ataque();
                    Console.Clear();

                    break;

                case 2:

                    Andar();
                    Console.Clear();

                    break;


                case 3:

                    Defender();
                    Console.Clear();

                    break;


                case 0:

                    goto sair;

                default:
                    break;
            }

        } while (true);

        sair: { }
    }

    public void Andar()
    {

        string modo = "pulou";
        movimento = dado.Next(1, 6);

        Console.WriteLine($"O ranger {modo} {movimento} casas nesse turno\n" + $"Precione enter para continuar...");
        Console.ReadLine();

    }

    public void Ataque()
    {
        int i = 0;
        string arma = "arco e flecha";

        dano = dado.Next(1, 7);
        soma += dano;

        Console.WriteLine($"O dano acertado pelo ataque com {arma} do ranger foi de {soma}\n" + $"Precione enter para continuar...");
        Console.ReadLine();
        soma = 0;
    }

    public void Defender()
    {
        string aparato = "esquiva";
        defesa = dado.Next(1, 7);

        Console.WriteLine($"O guerreiro defendeu com {aparato} {defesa} de dano\n" + $"Precione enter para continuar...");
        Console.ReadLine();

    }
}